﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EinkaufComp
{
    public static class Callbacks
    {
        public delegate void ProduktVerfuegbar();
    }
}

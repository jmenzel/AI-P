﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HES.AuftragserfassungComp.Repository.Entity
{
    /// <summary>
    /// Wird erstmal nicth benutzt
    /// </summary>
    [Serializable()]
    public enum AuftragStatusTyp
    {

    }
}

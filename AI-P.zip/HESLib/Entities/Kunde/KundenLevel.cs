﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HES.Kunde.Repository.Entity
{
    [Serializable()]
    public enum KundenLevel
    {
        Potentiell,
        Regulaer,
        HighOrder
    }
}
